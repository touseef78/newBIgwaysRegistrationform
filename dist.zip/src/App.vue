<script setup>
import Task from "./components/Task.vue"
// import * as VueGoogleMaps from 'vue2-google-maps'
// import Model from "./components/Model.vue"
</script>







<template>
  <Task />

  <!-- <Model /> -->
</template>



<!-- <style lang="scss">
@import "~@/assets/scss/vendors/bootstrap-vue/index";
</style> -->